// src/webview/store.svelte.js

// This is a reactive store using Svelte 5 runes.
// It holds the entire application state and is updated by messages from the extension host.

const initialContext = {
  workItems: [],
  organizations: [],
  projects: [],
  queries: [],
  currentConnectionId: undefined,
  currentOrganization: undefined,
  currentProject: undefined,
  currentQuery: undefined,
  error: undefined,
  user: undefined,
  authentication: undefined,
};

// `appState` is the single, reactive source of truth for the webview UI.
// We use `$state` to make the object deeply reactive.
export let appState = $state({
  fsmState: 'initializing',
  context: initialContext,
});

// Listen for messages from the extension host and update the appState.
window.addEventListener('message', (event) => {
  const message = event.data;

  // The extension host sends the entire FSM state and context on every change.
  // We just need to assign it to our reactive state object.
  if (message.fsmState && message.context) {
    appState.fsmState = message.fsmState;
    appState.context = message.context;
  }
});

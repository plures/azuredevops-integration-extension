<script lang="ts">
  import { onMount } from 'svelte';
  import { applicationMachine } from '../fsm/machines/applicationMachine.js';
  import { useMachine } from '@xstate/svelte';
  import WorkItemList from './components/WorkItemList.svelte';
  import Settings from './components/Settings.svelte';
  import StatusBar from './components/StatusBar.svelte';
  import { fsmLogger, FSMComponent } from '../fsm/logging/FSMLogger.js';
  import type { FSMContext } from '../fsm/logging/FSMLogger.js';
  //import { settings } from '../architecture/ReactiveStores.js';
  //console.log('Settings in App.svelte', $settings);
  console.log('App.svelte started');
  const { snapshot, send } = useMachine(applicationMachine);
  onMount(() => {
    fsmLogger.info(FSMComponent.WEBVIEW, 'Svelte component mounted', void 0, $snapshot);
  });
</script>

<main>
  {#if $snapshot.matches('CONNECTIONS-LOADED')}
    <p>connections loaded...</p>
  {:else if $snapshot.matches('CONNECTION-ESTABLISHED')}
    <p>Connection established</p>
  {:else if $snapshot.matches('error')}
    <div class="error-container">
      <h2>An Error Occurred</h2>
      <p>{$snapshot.error ?? 'Unknown error'}</p>
      <button on:click={() => send({ type: 'RETRY' })}>Retry</button>
    </div>
  {/if}
</main>

<style>
  main {
    padding: 1rem;
    height: calc(100vh - 30px); /* Adjust based on StatusBar height */
    overflow-y: auto;
  }

  .error-container {
    padding: 1rem;
    color: var(--vscode-errorForeground);
  }
</style>

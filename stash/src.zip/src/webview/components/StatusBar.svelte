<script lang="ts">
  // Placeholder for StatusBar component
</script>

<div>
  <p>Status Bar</p>
</div>

<script lang="ts">
  // Placeholder for WorkItemList component
</script>

<div>
  <p>Work Item List</p>
</div>

<h1>Hello from Minimal Svelte!</h1>

<style>
  h1 {
    color: white;
    font-family: sans-serif;
    text-align: center;
    margin-top: 2rem;
  }
</style>

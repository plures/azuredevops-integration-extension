export const EXTENSION_CONFIG_NAMESPACE = 'azureDevOpsIntegration';
export const LEGACY_EXTENSION_CONFIG_NAMESPACE = 'azureDevOps';
export const CONNECTIONS_CONFIG_STORAGE_KEY = 'connections';
export const ACTIVE_CONNECTION_STORAGE_KEY = 'azureDevOpsInt.activeConnectionId';
export const GLOBAL_PAT_SECRET_KEY = 'azureDevOpsInt.pat';

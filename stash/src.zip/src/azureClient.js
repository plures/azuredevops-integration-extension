/* STAGED FOR DELETION - snapshot preserved in .delete/src.azureClient.js.txt
   Reason: This file is an ESM re-export stub duplicating TypeScript source (src/azureClient.ts).
   Action: Convert imports to use extensionless TypeScript resolution or keep a single maintained stub. See ./.delete/README.md for details.
*/

export * from './azureClient.ts';

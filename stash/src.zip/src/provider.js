/* STAGED FOR DELETION - snapshot preserved in .delete/src.provider.js.txt
   Reason: Duplicate ESM re-export stub for TypeScript source (src/provider.ts).
   Action: Normalize imports and remove duplicate after tests and import strategy decided.
*/

export * from './provider.ts';
